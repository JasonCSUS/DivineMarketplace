package divinejason.divinemarketplace.listener;


/*
 * File role: Receives Bukkit player lifecycle events and clears per-player marketplace session/prompt state when a player disconnects.
 */
import divinejason.divinemarketplace.menu.MenuSessionManager;
import divinejason.divinemarketplace.prompt.MarketChatPromptService;
import java.util.Objects;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Handles player-scoped cleanup for menu sessions and pending chat prompts.
 */
public final class PlayerConnectionListener implements Listener {
    private final MenuSessionManager menuSessionManager;
    private final MarketChatPromptService chatPromptService;

    public PlayerConnectionListener(MenuSessionManager menuSessionManager, MarketChatPromptService chatPromptService) {
        this.menuSessionManager = Objects.requireNonNull(menuSessionManager, "menuSessionManager");
        this.chatPromptService = Objects.requireNonNull(chatPromptService, "chatPromptService");
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        menuSessionManager.clear(event.getPlayer().getUniqueId());
        chatPromptService.clearPlayer(event.getPlayer().getUniqueId());
    }
}
