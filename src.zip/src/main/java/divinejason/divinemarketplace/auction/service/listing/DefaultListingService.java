package divinejason.divinemarketplace.auction.service.listing;

/*
 * Layer : service
 * Owns  : listing behavior
 * Calls : stores (auction/storage) and registries only — never GUI or commands
 */


/*
 * File role: Implements listing service behavior using the SQLite stores, config registries, and item identity services.
 */
import divinejason.divinemarketplace.auction.model.ItemClaimRecord;
import divinejason.divinemarketplace.auction.model.Listing;
import divinejason.divinemarketplace.auction.model.ListingCreateFailureReason;
import divinejason.divinemarketplace.auction.model.ListingCreateResult;
import divinejason.divinemarketplace.auction.model.MarketEventRecord;
import divinejason.divinemarketplace.auction.model.MarketEventType;
import divinejason.divinemarketplace.auction.model.ResolvedItemDefinition;
import divinejason.divinemarketplace.auction.service.category.CategoryService;
import divinejason.divinemarketplace.auction.service.event.MarketEventService;
import divinejason.divinemarketplace.auction.service.identity.ItemIdentityResolver;
import divinejason.divinemarketplace.auction.service.identity.ListingPolicyResolver;
import divinejason.divinemarketplace.auction.service.purchase.MarketWriteTransaction;
import divinejason.divinemarketplace.auction.storage.sqlite.SQLiteItemClaimStore;
import divinejason.divinemarketplace.auction.storage.sqlite.SQLiteListingStore;
import divinejason.divinemarketplace.storage.sqlite.SQLiteWriteBatch;
import divinejason.divinemarketplace.storage.sqlite.SQLiteWriteBehindQueue;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * Concrete listing lifecycle implementation.
 *
 * Shared helper note:
 * - the actual create-or-merge listing persistence logic now lives in ListingWriteHelper
 * - this class stays focused on main-hand validation/removal and cancel/expire flow
 *
 * Event policy:
 * - one MarketEventRecord is written per list/cancel/expire action via marketEventService
 */
public final class DefaultListingService implements ListingService {
    private final Logger logger = Logger.getLogger(DefaultListingService.class.getName());
    private static final String ADMIN_CANCEL_PERMISSION = "divinemarketplace.admin.listing.cancel";
    private static final String ADMIN_PERMISSION = "divinemarketplace.admin";

    private final SQLiteListingStore listingStore;
    private final SQLiteItemClaimStore itemClaimStore;
    private final ItemIdentityResolver itemIdentityResolver;
    private final MarketEventService marketEventService;
    private final SQLiteWriteBehindQueue writeBehindQueue;
    private final CategoryService categoryService;
    private final ListingPolicyResolver listingPolicyResolver;
    private final ListingWriteHelper listingWriteHelper;

    public DefaultListingService(
            SQLiteListingStore listingStore,
            SQLiteItemClaimStore itemClaimStore,
            MarketEventService marketEventService,
            SQLiteWriteBehindQueue writeBehindQueue,
            ItemIdentityResolver itemIdentityResolver,
            CategoryService categoryService,
            ListingPolicyResolver listingPolicyResolver,
            ListingWriteHelper listingWriteHelper
    ) {
        this.listingStore = Objects.requireNonNull(listingStore, "listingStore");
        this.itemClaimStore = Objects.requireNonNull(itemClaimStore, "itemClaimStore");
        this.marketEventService = Objects.requireNonNull(marketEventService, "marketEventService");
        this.writeBehindQueue = Objects.requireNonNull(writeBehindQueue, "writeBehindQueue");
        this.itemIdentityResolver = Objects.requireNonNull(itemIdentityResolver, "itemIdentityResolver");
        this.categoryService = Objects.requireNonNull(categoryService, "categoryService");
        this.listingPolicyResolver = Objects.requireNonNull(listingPolicyResolver, "listingPolicyResolver");
        this.listingWriteHelper = Objects.requireNonNull(listingWriteHelper, "listingWriteHelper");
    }

    @Override
    public ListingCreateResult createOrMergeListing(Player seller, ItemStack sourceItem, int quantity, long unitPrice) {
        if (seller == null) {
            return ListingCreateResult.failure(ListingCreateFailureReason.INVALID_REQUEST, quantity, 0, "Seller was null.");
        }
        if (sourceItem == null || sourceItem.getType().isAir()) {
            return ListingCreateResult.failure(ListingCreateFailureReason.INVALID_REQUEST, quantity, 0, "sourceItem was null or air.");
        }
        if (quantity <= 0) {
            return ListingCreateResult.failure(ListingCreateFailureReason.INVALID_REQUEST, quantity, 0, "Requested quantity must be > 0.");
        }
        if (unitPrice <= 0L) {
            return ListingCreateResult.failure(ListingCreateFailureReason.INVALID_REQUEST, quantity, 0, "Unit price must be > 0.");
        }

        PlayerInventory inventory = seller.getInventory();
        SourceSelection selection;
        try {
            selection = selectMainHandSource(inventory, sourceItem);
        } catch (ListingCreateFailure failure) {
            return ListingCreateResult.failure(failure.reason(), quantity, 0, failure.getMessage());
        }

        int clampedQuantity = Math.min(quantity, selection.liveStack().getAmount());
        if (clampedQuantity <= 0) {
            return ListingCreateResult.failure(ListingCreateFailureReason.MAIN_HAND_EMPTY, quantity, 0, "Main-hand stack has no listable quantity.");
        }

        ItemStack normalizedSnapshot = normalizeSnapshotAmount(selection.liveStack());
        ResolvedItemDefinition resolved = itemIdentityResolver.resolve(normalizedSnapshot.clone());
        if (resolved == null) {
            return ListingCreateResult.failure(ListingCreateFailureReason.ITEM_IDENTITY_UNRESOLVED, quantity, clampedQuantity, "ItemIdentityResolver returned null.");
        }

        ListingPolicyResolver.ListingPolicy listingPolicy = listingPolicyResolver.resolve(seller);
        long nowEpochMillis = System.currentTimeMillis();

        RemovalReservation reservation;
        try {
            reservation = removeExactQuantityFromSlot(inventory, selection, clampedQuantity);
        } catch (ListingCreateFailure failure) {
            return ListingCreateResult.failure(failure.reason(), quantity, clampedQuantity, failure.getMessage());
        }

        MarketWriteTransaction transaction = new MarketWriteTransaction(logger);
        try {
            ListingWriteHelper.ListingWriteResult writeResult = listingWriteHelper.createOrMergeInMemory(
                    seller.getUniqueId(),
                    normalizedSnapshot,
                    clampedQuantity,
                    unitPrice,
                    resolved,
                    listingPolicy,
                    nowEpochMillis
            );
            registerListingWriteRollback(transaction, writeResult);

            Listing savedListing = writeResult.listing();
            MarketEventRecord listEvent = buildListingEvent(
                    MarketEventType.LIST,
                    savedListing,
                    seller.getUniqueId(),
                    nowEpochMillis,
                    writeResult.mergedIntoExisting() ? "MERGED" : "CREATED",
                    writeResult.mergedIntoExisting() ? "USER_MERGE" : "USER_LIST"
            );
            marketEventService.appendInMemory(listEvent);
            transaction.onRollback(() -> marketEventService.deleteInMemory(listEvent.eventId()));

            writeBehindQueue.enqueue(SQLiteWriteBatch.builder("create listing " + savedListing.listingId())
                    .add(listingStore.putMutation(savedListing))
                    .add(marketEventService.putMutation(listEvent))
                    .build());

            transaction.commit();

            return ListingCreateResult.success(
                    savedListing.listingId(),
                    writeResult.mergedIntoExisting(),
                    quantity,
                    clampedQuantity,
                    savedListing.marketKey(),
                    savedListing.marketDisplayName(),
                    savedListing.categoryId()
            );
        } catch (ListingWriteHelper.ListingWriteException exception) {
            transaction.rollbackQuietly();
            restoreReservation(inventory, reservation);
            return ListingCreateResult.failure(exception.failureReason(), quantity, clampedQuantity, exception.getMessage());
        } catch (RuntimeException exception) {
            transaction.rollbackQuietly();
            restoreReservation(inventory, reservation);
            return ListingCreateResult.failure(ListingCreateFailureReason.INTERNAL_ERROR, quantity, clampedQuantity, exception.getMessage());
        }
    }

    @Override
    public void cancelListing(Player actor, UUID listingId) {
        if (actor == null) {
            throw new IllegalArgumentException("actor cannot be null");
        }

        Listing listing = listingStore.findById(listingId)
                .orElseThrow(() -> new IllegalStateException("Listing not found: " + listingId));

        if (!mayCancel(actor, listing)) {
            throw new IllegalStateException("Actor is not allowed to cancel this listing.");
        }

        long nowEpochMillis = System.currentTimeMillis();
        MarketWriteTransaction transaction = new MarketWriteTransaction(logger);

        try {
            listingStore.deleteInMemory(listing.listingId());
            transaction.onRollback(() -> listingStore.saveOrReplaceInMemory(listing));

            ItemClaimRecord sellerClaim = createOrMergeItemClaimWithRollback(
                    transaction,
                    listing.sellerUuid(),
                    listing.listedItemSnapshot(),
                    listing.amount(),
                    nowEpochMillis
            );

            MarketEventRecord cancelEvent = buildListingEvent(
                    MarketEventType.CANCEL,
                    listing,
                    actor.getUniqueId(),
                    nowEpochMillis,
                    "CANCELLED",
                    actor.getUniqueId().equals(listing.sellerUuid()) ? "SELLER_CANCEL" : "ADMIN_CANCEL"
            );
            marketEventService.appendInMemory(cancelEvent);
            transaction.onRollback(() -> marketEventService.deleteInMemory(cancelEvent.eventId()));

            writeBehindQueue.enqueue(SQLiteWriteBatch.builder("cancel listing " + listing.listingId())
                    .add(listingStore.deleteMutation(listing.listingId()))
                    .add(itemClaimStore.putMutation(sellerClaim))
                    .add(marketEventService.putMutation(cancelEvent))
                    .build());

            transaction.commit();
        } catch (RuntimeException exception) {
            transaction.rollbackQuietly();
            throw exception;
        }

        categoryService.refreshIndexesFor(listing.marketKey(), listing.categoryId());
    }

    @Override
    public void expireDueListings(long nowEpochMillis) {
        Iterable<Listing> active = listingStore.getAllActive();
        Set<String> affectedCategoryIds = new LinkedHashSet<>();

        for (Listing listing : active) {
            long expiresAt = listing.listedAtEpochMillis() + listing.listingDurationMillis();
            if (nowEpochMillis < expiresAt) {
                continue;
            }

            MarketWriteTransaction transaction = new MarketWriteTransaction(logger);

            try {
                listingStore.deleteInMemory(listing.listingId());
                transaction.onRollback(() -> listingStore.saveOrReplaceInMemory(listing));

                ItemClaimRecord sellerClaim = createOrMergeItemClaimWithRollback(
                        transaction,
                        listing.sellerUuid(),
                        listing.listedItemSnapshot(),
                        listing.amount(),
                        nowEpochMillis
                );

                MarketEventRecord expireEvent = buildListingEvent(
                        MarketEventType.EXPIRE,
                        listing,
                        listing.sellerUuid(),
                        nowEpochMillis,
                        "EXPIRED",
                        "LISTING_DURATION_ELAPSED"
                );
                marketEventService.appendInMemory(expireEvent);
                transaction.onRollback(() -> marketEventService.deleteInMemory(expireEvent.eventId()));

                writeBehindQueue.enqueue(SQLiteWriteBatch.builder("expire listing " + listing.listingId())
                        .add(listingStore.deleteMutation(listing.listingId()))
                        .add(itemClaimStore.putMutation(sellerClaim))
                        .add(marketEventService.putMutation(expireEvent))
                        .build());

                transaction.commit();
                affectedCategoryIds.add(listing.categoryId());
            } catch (RuntimeException exception) {
                transaction.rollbackQuietly();
                logger.warning("Failed to expire listing " + listing.listingId() + ": " + exception.getMessage());
            }
        }

        categoryService.refreshIndexesForCategories(affectedCategoryIds);
    }

    private SourceSelection selectMainHandSource(PlayerInventory inventory, ItemStack sourceItem) {
        int heldSlot = inventory.getHeldItemSlot();
        ItemStack[] storageContents = inventory.getStorageContents();

        if (heldSlot < 0 || heldSlot >= storageContents.length) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_STACK_CHANGED, "Held slot index is outside storage contents.");
        }

        ItemStack held = storageContents[heldSlot];
        if (held == null || held.getType().isAir()) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_EMPTY, "Main hand is empty.");
        }

        ItemStack heldComparable = normalizeSnapshotAmount(held);
        ItemStack requestedComparable = normalizeSnapshotAmount(sourceItem);

        if (!heldComparable.isSimilar(requestedComparable)) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_ITEM_MISMATCH, "Main-hand item no longer matches the requested listing item.");
        }

        return new SourceSelection(heldSlot, held.clone());
    }

    private RemovalReservation removeExactQuantityFromSlot(PlayerInventory inventory, SourceSelection selection, int quantity) {
        ItemStack[] storageContents = inventory.getStorageContents();
        ItemStack current = storageContents[selection.slotIndex()];

        if (current == null || current.getType().isAir()) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_STACK_CHANGED, "Main-hand source stack vanished before removal.");
        }

        ItemStack liveComparable = normalizeSnapshotAmount(current);
        ItemStack expectedComparable = normalizeSnapshotAmount(selection.liveStack());

        if (!liveComparable.isSimilar(expectedComparable)) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_STACK_CHANGED, "Main-hand source stack changed before removal.");
        }

        if (current.getAmount() < quantity) {
            throw new ListingCreateFailure(ListingCreateFailureReason.MAIN_HAND_STACK_CHANGED, "Main-hand stack no longer has enough quantity.");
        }

        ItemStack original = current.clone();
        int remainingAmount = current.getAmount() - quantity;
        storageContents[selection.slotIndex()] = remainingAmount > 0 ? cloneWithAmount(current, remainingAmount) : null;
        inventory.setStorageContents(storageContents);

        return new RemovalReservation(selection.slotIndex(), original);
    }

    private void restoreReservation(PlayerInventory inventory, RemovalReservation reservation) {
        ItemStack[] storageContents = inventory.getStorageContents();
        storageContents[reservation.slotIndex()] = reservation.originalStack().clone();
        inventory.setStorageContents(storageContents);
    }

    private ItemClaimRecord createOrMergeItemClaimWithRollback(MarketWriteTransaction transaction, UUID ownerUuid, ItemStack baseSnapshot, int amount, long createdAtEpochMillis) {
        ItemStack normalizedSnapshot = normalizeSnapshotAmount(baseSnapshot);
        ItemClaimRecord previousMergeTarget = findExistingSimilarClaim(ownerUuid, normalizedSnapshot);
        ItemClaimRecord incomingClaim = new ItemClaimRecord(
                UUID.randomUUID(),
                ownerUuid,
                normalizedSnapshot,
                amount,
                createdAtEpochMillis
        );
        ItemClaimRecord savedClaim = itemClaimStore.mergeOrCreateInMemory(incomingClaim);
        transaction.onRollback(() -> {
            if (previousMergeTarget == null) {
                itemClaimStore.deleteInMemory(savedClaim.claimId(), ownerUuid);
            } else {
                itemClaimStore.saveOrReplaceInMemory(previousMergeTarget);
            }
        });
        return savedClaim;
    }

    private ItemClaimRecord findExistingSimilarClaim(UUID ownerUuid, ItemStack normalizedSnapshot) {
        for (ItemClaimRecord claim : itemClaimStore.findByOwner(ownerUuid, 0, Integer.MAX_VALUE)) {
            if (itemsSimilarIgnoringAmount(claim.claimItemSnapshot(), normalizedSnapshot)) {
                return claim;
            }
        }
        return null;
    }

    private boolean itemsSimilarIgnoringAmount(ItemStack left, ItemStack right) {
        ItemStack leftCopy = normalizeSnapshotAmount(left);
        ItemStack rightCopy = normalizeSnapshotAmount(right);
        return leftCopy.isSimilar(rightCopy);
    }

    private void registerListingWriteRollback(MarketWriteTransaction transaction, ListingWriteHelper.ListingWriteResult writeResult) {
        transaction.onRollback(() -> listingWriteHelper.rollbackWriteInMemory(writeResult));
    }

    private MarketEventRecord buildListingEvent(
            MarketEventType type,
            Listing listing,
            UUID actorUuid,
            long timestampEpochMillis,
            String status,
            String reason
    ) {
        return new MarketEventRecord(
                UUID.randomUUID().toString(),
                timestampEpochMillis,
                type,
                listing.listingId().toString(),
                listing.sellerUuid(),
                null,
                actorUuid,
                listing.marketKey(),
                listing.marketDisplayName(),
                listing.categoryId(),
                listing.marketDisplayName() + " x" + listing.amount(),
                null,
                listing.amount(),
                listing.unitPrice() * listing.amount(),
                listing.unitPrice(),
                status,
                reason,
                null
        );
    }

    private boolean mayCancel(Player actor, Listing listing) {
        return actor.getUniqueId().equals(listing.sellerUuid())
                || actor.hasPermission(ADMIN_PERMISSION)
                || actor.hasPermission(ADMIN_CANCEL_PERMISSION);
    }

    private ItemStack normalizeSnapshotAmount(ItemStack input) {
        ItemStack copy = input.clone();
        copy.setAmount(1);
        return copy;
    }

    private ItemStack cloneWithAmount(ItemStack input, int amount) {
        ItemStack copy = input.clone();
        copy.setAmount(amount);
        return copy;
    }

    private record SourceSelection(int slotIndex, ItemStack liveStack) {
    }

    private record RemovalReservation(int slotIndex, ItemStack originalStack) {
    }

    private static final class ListingCreateFailure extends RuntimeException {
        private final ListingCreateFailureReason reason;

        private ListingCreateFailure(ListingCreateFailureReason reason, String message) {
            super(message);
            this.reason = reason;
        }

        private ListingCreateFailureReason reason() {
            return reason;
        }
    }
}
